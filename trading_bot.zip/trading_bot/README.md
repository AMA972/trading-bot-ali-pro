# TradingBot Pro

Bot de trading autonome multi-exchange et multi-stratégie.

## Architecture

```
trading_bot/
├── main.py                        # Point d'entrée
├── config/
│   └── settings.py                # Chargement et validation de la config
├── core/
│   ├── bot_engine.py              # Orchestrateur principal
│   ├── exchange_manager.py        # Connexion aux exchanges (via ccxt)
│   └── regime_detector.py        # Détection du régime de marché
├── strategies/
│   ├── base_strategy.py           # Classe abstraite
│   ├── trend_following.py         # EMA crossover + ADX
│   ├── mean_reversion.py          # Bollinger Bands + RSI
│   ├── momentum.py                # MACD + volume surge
│   └── registry.py                # Registre des stratégies
├── risk/
│   └── risk_manager.py            # Gestion du risque (le module le plus important)
└── monitoring/
    └── monitor.py                 # Alertes, métriques, historique
```

## Comment les problèmes classiques sont résolus

| Problème | Solution implémentée |
|---|---|
| Mauvais paramétrage → pertes | RiskManager : stop-loss automatique, circuit breaker sur drawdown max, R/R minimum 1.5:1 |
| Stratégie qui devient obsolète | RegimeDetector : détecte automatiquement le régime (trend/ranging/volatile) et sélectionne la meilleure stratégie |
| Surveillance régulière | Monitor : alertes webhook (Slack/Discord/Telegram), logs rotatifs, résumé de performance automatique |
| APIs qui changent | ccxt : une seule lib qui unifie 100+ exchanges. Changer d'exchange = une ligne dans config.yaml |

## Installation

```bash
pip install -r requirements.txt
```

## Configuration

```bash
# Copier l'exemple de config (généré au premier démarrage)
cp config/config.example.yaml config/config.yaml

# Renseigner vos clés API (via variables d'environnement, recommandé)
export BINANCE_API_KEY="votre_clé"
export BINANCE_API_SECRET="votre_secret"
```

## Démarrage

```bash
# Mode dry run (simulation, aucun argent réel)
python main.py

# Pour passer en réel : dans config.yaml, mettre dry_run: false
# ATTENTION : assurez-vous d'avoir testé longuement en sandbox d'abord
```

## Paramètres de risque importants (config.yaml)

```yaml
risk:
  max_portfolio_risk_pct: 1.0   # Max 1% du capital en risque simultané
  max_single_trade_risk_pct: 0.5 # Max 0.5% par trade
  max_drawdown_pct: 10.0         # Le bot se met en pause si -10% de drawdown
  stop_loss_pct: 2.0             # Stop-loss à 2% de l'entrée
  take_profit_pct: 4.0           # Take-profit à 4% (R/R = 2:1)
  position_sizing: kelly         # Kelly Criterion pour sizing dynamique
```

## Ajouter une nouvelle stratégie

1. Créer `strategies/ma_strategie.py` héritant de `BaseStrategy`
2. Implémenter `generate_signal(ohlcv) -> Signal`
3. L'enregistrer dans `strategies/registry.py`
4. L'ajouter dans `config.yaml` → `strategy.active_strategies`

## Ajouter un exchange

Il suffit d'ajouter dans `config.yaml` :
```yaml
exchanges:
  - id: kraken   # N'importe quel exchange supporté par ccxt
    api_key_env: KRAKEN_API_KEY
    api_secret_env: KRAKEN_API_SECRET
    sandbox: true
```

## Alertes

Configurez un webhook dans `config.yaml` :
```yaml
monitoring:
  alert_webhook: "https://hooks.slack.com/services/..."
  # Fonctionne aussi avec Discord et Telegram
```

## ⚠️ Avertissement

Le trading comporte des risques de perte en capital.
- Commencez TOUJOURS en `dry_run: true`
- Testez en sandbox avant tout argent réel
- Ne tradez jamais plus que ce que vous pouvez vous permettre de perdre
- Ce bot est un outil, pas une garantie de profit
